#include<stdio.h>

void square_peri(int side);
void square_area(int side);
