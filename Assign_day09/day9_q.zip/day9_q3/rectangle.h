#include<stdio.h>

void rect_peri(int len, int bre);
void rect_area(int len, int bre);
