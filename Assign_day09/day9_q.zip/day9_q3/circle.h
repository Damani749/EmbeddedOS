#define pi 3.142

void circle_peri(int rad);
void circle_arer(int rad);
